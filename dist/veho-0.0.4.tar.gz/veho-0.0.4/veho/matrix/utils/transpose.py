def transpose(mx):
    return [*zip(*mx)]
