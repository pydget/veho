def row(mx, x):
    return mx[x]