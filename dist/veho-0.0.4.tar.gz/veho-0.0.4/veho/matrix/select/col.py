def col(mx, y):
    return [row[y] for row in mx]

# return [mx[x][y] for x in range(len(mx))]
