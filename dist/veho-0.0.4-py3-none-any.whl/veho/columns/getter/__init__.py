def column(mx, c):
    return [r[c] for r in mx]
