def length(arr: list):
    return None if arr is None else len(arr)
