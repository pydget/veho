def shallow(vec: list):
    return vec[:]

# return [x for x in vec]
# return copy.copy(vec)
