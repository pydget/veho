## veho
##### easy enumerate

### Usage
```python
from veho.vector import mapper
vect = [1,2,3]
print(mapper(vect,lambda x:x+1))
```