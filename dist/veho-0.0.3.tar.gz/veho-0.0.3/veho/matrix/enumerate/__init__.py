from .mapper import iterate, mapper, mutate
from .margin import margin_mapper, margin_mutate, margin_shallow
from .zipper import duozipper, mutazip, quazipper, to_duozipper, to_quazipper, to_trizipper, trizipper, zipper
