from typing import List, Any


def push(vec: List[Any], element: Any):
    vec.append(element)
    return vec
