def mapper(vec, fn):
    return [fn(x) for x in vec]
