def swap(vec, i, j):
    vec[i], vec[j] = vec[j], vec[i]
    return vec[j]
